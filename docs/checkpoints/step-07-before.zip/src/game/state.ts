import type { GameState, ItemId } from "./types.ts";

export function createGame(): GameState {
  return {
    scene: "arrival", day: 1, time: "night", forestSteps: 0,
    inventory: [], ringDroppedOnDay: null, fusion: 0, breakfast: "unresolved",
    flags: {
      ringFound: false, portraitSeen: false, doorplatesSeen: false,
      ruinsSeen: false, enteredInn: false, emilySawRing: false, ringInscriptionRead: false,
      registrySeen: false, checkedIn: false, ownEntrySeen: false,
      hallPortraitSeen: false, neighborRoomSeen: false, firstNightSlept: false,
      foodExamined: false, basementUnlocked: false, peacefulSleepUsed: false,
      basementTruthSeen: false, pillarExamined: false, tapExamined: false,
      rescuedFromBasement: false, emilyAdmittedHouse: false,
    },
  };
}

export function hasItem(state: GameState, item: ItemId): boolean {
  return state.inventory.includes(item);
}

export function addItem(state: GameState, item: ItemId): GameState {
  return hasItem(state, item) ? state : { ...state, inventory: [...state.inventory, item] };
}

export function knownClues(state: GameState): string[] {
  const clues: string[] = [];
  if (state.flags.portraitSeen) clues.push("全家福画像背面写着“艾米莉”，年份是 1682。");
  if (state.flags.doorplatesSeen) clues.push("遗迹中有“爱德华与艾米莉之家”的门牌。");
  if (state.flags.ringInscriptionRead) clues.push("戒指内侧刻着：艾米莉，I love you forever。");
  if (state.flags.registrySeen) clues.push("旅馆登记簿上，旧住客都有入住日期，退房栏却整列空着。");
  if (state.flags.ownEntrySeen) clues.push("登记簿上已经有了你的名字，你那一行的退房日期也是空白。");
  if (state.flags.hallPortraitSeen) clues.push("走廊里的肖像画保养得异常完好，目光仿佛跟着人移动。");
  if (state.flags.neighborRoomSeen) clues.push("隔壁房门虚掩，屋内空着；家具移动般的声音似乎来自更下方。");
  if (state.flags.foodExamined) clues.push("早餐盘里是香肠，肉的颜色和气味有些陌生。");
  if (hasItem(state, "oldLedger")) clues.push("旧账本记载，厨房曾为一场婚庆准备蛋糕、猪肉香肠和啤酒。");
  if (hasItem(state, "adultPhoto")) clues.push(state.flags.portraitSeen
    ? "前台锁柜里的合影像是长大后的艾米莉与一位男人；背面写着男人送她一枚亲手做的戒指。"
    : "前台锁柜里的合影背面写着：一位男人送给画中的女子一枚亲手做的戒指。");
  if (state.flags.basementUnlocked) clues.push("井里得到的银白色钥匙打开了旅馆地下室的门。");
  if (state.flags.basementTruthSeen) clues.push("地下室深处的石壁混着木纹，甚至长出像食物形状的肉瘤。");
  if (state.flags.pillarExamined) clues.push(state.flags.doorplatesSeen
    ? "地下室倒塌石柱的纹路，与遗迹中爱德华和艾米莉之家附近的石料相似。"
    : "地下室倒塌的石柱与遗迹里的石料很相似。");
  if (state.flags.tapExamined) clues.push("地下室墙上的龙头流出有酒香的液体，后面的墙却像在微微起伏。");
  if (state.flags.rescuedFromBasement) clues.push("你在地下室水下失去意识后，被一只手拉起，醒在自己的客房。");
  if (state.flags.emilyAdmittedHouse) clues.push("前台小姐承认地下室与他们过去的家有关，却说“以前不是它的”。");
  return clues;
}
