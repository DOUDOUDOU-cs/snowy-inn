# 雪夜旅馆（暂定名）

一款以文字、选项和调查为核心的离线叙事游戏，使用 TypeScript、Vite 和 Tauri 2。

## 目前可以玩什么

第一步已实现标题页、雪夜开场和两条选择的第一段反馈。每条路线的试玩终点会明确提示，可以返回开场或标题。物品、日期、融合、十次赶路结局和存档尚未接入；刷新页面会回到标题。

## 启动

在 VS Code 中打开本文件所在的 game 文件夹，再打开终端。

浏览器预览：

```powershell
npm.cmd run dev
```

打开终端显示的地址，默认是 http://localhost:1420 。

桌面窗口预览：

```powershell
npm.cmd run tauri dev
```

两种模式分别启动即可；若浏览器预览已占用 1420 端口，先在原终端按 Ctrl+C，再启动桌面模式。

检查与构建：

```powershell
npm.cmd run build
```

## 先认识四个文件

| 文件 | 作用 |
| --- | --- |
| src/story/opening.ts | 开场文字和每个选项去往哪里；以后改剧情先看这里 |
| src/main.ts | 把故事显示出来，并响应按钮点击 |
| src/styles.css | 控制字号、颜色、间距及小屏幕布局 |
| index.html | 页面入口和作为气氛示意的旅馆剪影 |

目前图形全部在本地绘制，字体使用系统字体，无外部图片或字体下载。标题暂用“雪夜旅馆”，正文为原设计的开场改编，可继续调整。

每轮改动见 [开发记录](docs/开发记录.md)。第一步修改前的示例备份位于 docs/checkpoints/step-01-before.zip，包含原 src、index.html 和 README.md。
