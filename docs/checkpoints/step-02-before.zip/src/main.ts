import { openingScenes, type SceneId } from "./story/opening";

const root = document.querySelector<HTMLElement>("#app");
if (!root) throw new Error("找不到游戏显示区域 #app。");
const app: HTMLElement = root;

// 本阶段只负责标题和开场；物品、时间和存档将在后续步骤加入。
function renderTitle(): void {
  app.innerHTML = `
    <section class="title-screen screen" aria-labelledby="game-title">
      <p class="eyebrow">一八六〇年 · 冬</p>
      <h1 id="game-title" tabindex="-1">雪夜旅馆</h1>
      <p class="title-description">漫长的风雪里，<br>终于有一扇窗，还亮着灯。</p>
      <button class="start-button" type="button">开始游戏 <span aria-hidden="true">→</span></button>
      <p class="edition">开场试玩</p>
    </section>`;
  app.querySelector<HTMLButtonElement>(".start-button")!.addEventListener("click", () => renderScene("arrival"));
  app.querySelector<HTMLElement>("h1")!.focus({ preventScroll: true });
}

function renderScene(id: SceneId): void {
  const scene = openingScenes[id];
  app.innerHTML = `
    <section class="story-screen screen" aria-labelledby="scene-title">
      <nav class="story-nav" aria-label="游戏导航">
        <button class="text-button" type="button">← 返回标题</button>
        <span>序章 · 雪夜</span>
      </nav>
      <p class="eyebrow scene-location"></p>
      <h1 id="scene-title" tabindex="-1"></h1>
      <div class="narrative"></div>
      <div class="choices" role="group" aria-label="选择下一步"></div>
    </section>`;

  app.querySelector<HTMLElement>(".scene-location")!.textContent = scene.location;
  const heading = app.querySelector<HTMLElement>("h1")!;
  heading.textContent = scene.title;
  const narrative = app.querySelector<HTMLElement>(".narrative")!;
  for (const paragraph of scene.paragraphs) {
    const element = document.createElement("p");
    element.textContent = paragraph;
    narrative.append(element);
  }

  const choices = app.querySelector<HTMLElement>(".choices")!;
  for (const choice of scene.choices) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "choice-button";
    const label = document.createElement("span");
    label.textContent = choice.text;
    const arrow = document.createElement("span");
    arrow.textContent = "→";
    arrow.setAttribute("aria-hidden", "true");
    button.append(label, arrow);
    button.addEventListener("click", () => renderScene(choice.next));
    choices.append(button);
  }

  if (scene.previewEnd) {
    const endNote = document.createElement("aside");
    endNote.className = "preview-end";
    const text = document.createElement("p");
    text.textContent = "开场试玩暂时到这里。回到开场，可以尝试另一条路线。";
    const restart = document.createElement("button");
    restart.type = "button";
    restart.className = "text-button";
    restart.textContent = "回到开场 →";
    restart.addEventListener("click", () => renderScene("arrival"));
    endNote.append(text, restart);
    choices.append(endNote);
  }

  app.querySelector<HTMLButtonElement>(".story-nav button")!.addEventListener("click", renderTitle);
  window.scrollTo({ top: 0, behavior: "instant" });
  heading.focus({ preventScroll: true });
}

renderTitle();
