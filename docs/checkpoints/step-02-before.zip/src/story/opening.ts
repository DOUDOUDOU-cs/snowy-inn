// 剧情文字放在这里，页面如何显示由 main.ts 负责。
// next 必须指向已有场景；拼错名称时，TypeScript 会提示错误。
export type SceneId = "arrival" | "entrance" | "forest";

interface Choice {
  text: string;
  next: SceneId;
}

interface Scene {
  location: string;
  title: string;
  paragraphs: string[];
  choices: Choice[];
  previewEnd?: boolean;
}

export const openingScenes: Record<SceneId, Scene> = {
  arrival: {
    location: "森林边缘",
    title: "风雪中的灯光",
    paragraphs: [
      "1860 年的一个雪夜。经过长途跋涉，你的脚步已经越来越沉。",
      "风穿过暗处的树枝。前方，一间旅馆的窗户透出昏黄的灯光。",
      "你在路边停了下来。",
    ],
    choices: [
      { text: "进入旅馆附近", next: "entrance" },
      { text: "不顾疲惫，继续赶路", next: "forest" },
    ],
  },
  entrance: {
    location: "旅馆外",
    title: "孤零零的旅馆",
    paragraphs: [
      "你离开积雪的道路，朝灯光走去。",
      "旅馆的规模不小，周围却看不到配套的村庄。风雪之间，只能辨出几口水井的轮廓。",
      "再往前，就是旅馆的门。",
    ],
    choices: [],
    previewEnd: true,
  },
  forest: {
    location: "林间小路",
    title: "又一盏熟悉的灯",
    paragraphs: [
      "你收回目光，继续向森林深处走去。",
      "暗夜的密林和乌鸦的叫声，逐渐扰乱了你的判断。你已经说不清自己走了多久。",
      "模模糊糊中，前方又出现了那间旅馆。",
    ],
    choices: [],
    previewEnd: true,
  },
};
