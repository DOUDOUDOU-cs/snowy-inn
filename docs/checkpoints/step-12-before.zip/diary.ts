import type { GameState, SceneId } from "./types.ts";

export interface DiaryEntry {
  key: string;
  day: number;
  time: GameState["time"];
  title: string;
  text: string;
  ending?: string;
}

export interface LegacyStep {
  scene: SceneId;
  day: number;
  time: GameState["time"];
  paragraphs: string[];
  choice?: { id: string; text: string };
  ending?: string;
}

type DiaryDraft = Pick<DiaryEntry, "key" | "title" | "text" | "ending">;

export const openingDiary = (state: Pick<GameState, "day" | "time">): DiaryEntry => ({
  key: "departure", day: state.day, time: state.time,
  title: "雪夜出发", text: "风雪里，我看见一间窗户亮着灯的旅馆。我在路边停下，决定接下来往哪里走。",
});

// 每个条目只记一次真正改变经历的发现或决定；普通往返不写入日记。
function draftForStep(choice: string, scene: SceneId, ownNameSeen = false): DiaryDraft | null {
  if (scene === "escape") return { key: "escape", title: "走出森林", text: "我没有走进那间旅馆。一直向前后，身后的树木终于让出一条路；这次回头，灯光没有再出现。", ending: "结局 · 一直向前" };
  if (scene === "drownedEnding") return { key: "drowned", title: "水下", text: "我跳进水道深处。黑暗和冷水一点点盖过声音，最后没有人再把我拉起来。", ending: "结局 · 水下的寂静" };
  if (scene === "checkoutEnding") return { key: "checkout", title: "写下退房日期", text: "我在登记簿上写下今天的退房日期。前台小姐让开了路；这次推门走出去，路没有再绕回来。", ending: "结局 · 退房" };
  if (scene === "innkeeperEnding") return { key: "innkeeper", title: "新旅人", text: "我坐在柜台后。一个浑身是雪的旅人问还有没有空房，我抬起头，听见自己回答：“……当然。”", ending: "结局 · 前台" };
  if (choice === "walk" && scene === "ruins") return { key: "ruins", title: "林中的遗迹", text: "我一次次绕过那盏灯，最后在雪下撞见墓碑与坍塌的村屋。这里曾有人生活过。" };
  if (choice === "take-ring") return { key: "ring", title: "碎木里的戒指", text: "我在碎木屑里找到一枚戒指，把它收了起来。不知是谁把它留在这片遗迹中。" };
  if (choice === "house") return { key: "portrait", title: "旧画像", text: "我从半塌的小屋里带走一幅全家福画像。背面写着艾米莉，以及 1682 年。" };
  if (choice === "doorplates") return { key: "doorplates", title: "留下的名字", text: "我辨认出村屋的旧门牌，其中一块写着“爱德华与艾米莉之家”。" };
  if (choice === "enter") return { key: "entered", title: "推开旅馆的门", text: "我终于走进那间旅馆。前台小姐说还有空房，门内的暖意让外面的雪忽然显得很远。" };
  if (choice === "drop-ring") return { key: "ring-well", title: "井中的戒指", text: "我把戒指投进旅馆旁的水井。水面很快平静下来，井底却像藏着什么。" };
  if (choice === "lift-bucket" || (choice === "pull-rope" && scene === "silverKey")) return { key: "silver-key", title: "井里的银钥匙", text: "我把湿滑的井绳搭上轱辘、绕紧在手上，终于拉起木桶。桶里没有水，只有一把银白色钥匙。" };
  if (choice === "look-registry" || choice === "open-registry") return ownNameSeen
    ? { key: "my-registry", title: "我的名字", text: "登记簿里已经有了我的名字，入住日期清清楚楚，退房那一栏却依旧空着。" }
    : { key: "registry", title: "空白的退房栏", text: "我翻看登记簿。旧住客都有入住日期，退房日期却整列空白。" };
  if (choice === "finish-check-in") return { key: "checked-in", title: "入住", text: "我写下名字和日期，接过客房钥匙。笔落在纸上的时候，我又看了一眼那些空白的退房栏。" };
  if (choice === "look-hall-portrait") return { key: "hall-portrait", title: "灯下的肖像", text: "我看着前台后的肖像，稍稍移开一步，仍觉得画中人的目光落在身上。" };
  if (choice === "sleep") return { key: "first-night", title: "第一夜", text: "楼下的响动没有停。我用纸巾堵住耳朵，终于在旅馆里睡过了第一夜。" };
  if (choice === "inspect-food") return { key: "food", title: "早餐的气味", text: "我拨开早餐的香肠。肉色与那股甜味都不像熟悉的猪肉。" };
  if (choice === "eat-breakfast") return { key: "breakfast", title: "吃下早餐", text: "我把早餐吃了下去。胃里暖起来时，竟觉得这张餐桌像是已经坐过许多次。" };
  if (choice === "pretend-breakfast") return { key: "breakfast", title: "没吃的早餐", text: "我假装吃过早餐，把餐具轻轻放好。前台小姐端走盘子，没有追问。" };
  if (choice === "decline-breakfast") return { key: "breakfast", title: "谢绝早餐", text: "我谢绝了她的早餐。她只说路上小心，然后端着盘子离开。" };
  if (choice === "search-wardrobe") return { key: "bronze-key", title: "衣柜里的钥匙", text: "隔壁房间空着。我打开衣柜，在靠里的木板上找到一把古铜色钥匙。" };
  if (choice === "search-desk") return { key: "old-ledger", title: "旧账本", text: "我趁前台无人翻开上层抽屉，拿到一本记录着旧日婚宴的账本。" };
  if (choice === "unlock-cabinet") return { key: "photo", title: "柜里的合影", text: "我用古铜色钥匙打开锁柜，从衣物下取出一张旧合影。背面提到一枚亲手做的戒指。" };
  if (choice === "unlock-basement") return { key: "basement-key", title: "地下室的门", text: "井里得到的银白色钥匙，打开了通往旅馆地下室的门。" };
  if (choice === "follow-wall" && scene === "fleshCorridor") return { key: "basement-truth", title: "墙后的东西", text: "我没有跳进水洞，而是沿墙走下去。石头里混着木纹与肉，旅馆的墙似乎还在呼吸。" };
  if (choice === "inspect-pillar") return { key: "pillar", title: "倒塌的石柱", text: "地下室里的石柱让我想起村庄遗迹。那些旧房子，也许并没有真正离开这里。" };
  if (choice === "inspect-tap") return { key: "tap", title: "墙上的龙头", text: "我拧开墙上的龙头，流出的液体带着酒香；墙面在手边微微起伏。" };
  if (scene === "underwaterRescue") return { key: "rescued", title: "水下的手", text: "我在水下快要失去意识时，被一只手拉住。没看清那是谁，水声已经离我远去。" };
  if (choice === "stay-one-more-night") return { key: "stayed", title: "又住一晚", text: "明知道地下室不对劲，我还是决定在这里再住一晚。去前台的路已经熟悉得不像初来时。" };
  if (choice === "continue-truth") return { key: "emily-house", title: "她的旧家", text: "我追问地下室。艾米莉承认那里与他们过去的家有关，却说它以前不是这个样子。" };
  if (choice === "ask-why-stay") return { key: "wedding", title: "婚礼之后", text: "艾米莉告诉我，婚礼那晚风雪太大，大家留了下来。再问第二天，她说他们没有离开。" };
  if (choice === "ask-inn") return { key: "inn-nature", title: "旅馆的来历", text: "她说旅馆先出现在村庄旁，后来渐渐吞下旧房子。她也分不清是谁需要谁。" };
  if (choice === "ask-leave" || choice === "ask-leave-now") return { key: "checkout-hint", title: "离开的办法", text: "我问怎样离开。她没有指向门，只看向登记簿里我名字旁空白的退房日期。" };
  return null;
}

function withMoment(draft: DiaryDraft, day: number, time: GameState["time"]): DiaryEntry {
  return { ...draft, day, time };
}

export function diaryForChoice(before: GameState, choice: string, after: GameState): DiaryEntry | null {
  const draft = before.flags.enteredInn && before.forestSteps < 13 && after.forestSteps >= 13
    ? { key: "forest-closed", title: "绕回门前", text: "我又一次沿来路往外走，还是回到了旅馆的灯下。这条路已经试够了。", } satisfies DiaryDraft
    : draftForStep(choice, after.scene, after.flags.ownEntrySeen);
  return draft ? withMoment(draft, after.day, after.time) : null;
}

export function diaryForItem(before: GameState, after: GameState): DiaryEntry | null {
  if (!before.flags.ringInscriptionRead && after.flags.ringInscriptionRead) {
    return withMoment({ key: "ring-inscription", title: "戒指内侧", text: "我把戒指凑近旅馆的灯光，读到内侧刻着：艾米莉，I love you forever。" }, after.day, after.time);
  }
  return null;
}

// 第一版存档原本逐节点记录；升级时只抽取关键事件，旧局仍可回看。
export function condenseLegacy(steps: LegacyStep[]): DiaryEntry[] {
  const first = steps[0]!;
  const entries = [openingDiary(first)];
  for (let index = 1; index < steps.length; index++) {
    const previous = steps[index - 1]!;
    const current = steps[index]!;
    const choice = previous.choice?.id;
    if (!choice) continue;
    const ownNameSeen = current.paragraphs.some(text => text.includes("你的名字"));
    const draft = draftForStep(choice, current.scene, ownNameSeen);
    if (draft && !entries.some(entry => entry.key === draft.key)) entries.push(withMoment(draft, current.day, current.time));
  }
  return entries;
}
