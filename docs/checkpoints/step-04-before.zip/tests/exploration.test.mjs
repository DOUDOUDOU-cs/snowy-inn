import test from 'node:test';
import assert from 'node:assert/strict';
import { createGame, knownClues } from '../src/game/state.ts';
import { choose, getScene, inspectItem } from '../src/game/engine.ts';

function route(...choices) {
  return choices.reduce((state, id) => {
    assert.ok(getScene(state).choices.some(choice => choice.id === id), `选项 ${id} 应在 ${state.scene} 中可用`);
    return choose(state, id);
  }, createGame());
}
const findRing = () => route('walk', 'walk', 'walk', 'rest', 'take-ring');

test('第三次赶路发现遗迹，第十次才离开，沿途文字发生变化', () => {
  let state = createGame();
  const texts = new Set();
  for (let count = 1; count <= 10; count++) {
    state = choose(state, 'walk');
    assert.equal(state.forestSteps, count);
    if (count === 3) assert.equal(state.scene, 'ruins');
    if (count < 10) assert.notEqual(state.scene, 'escape');
    if (count >= 4 && count <= 9) texts.add(getScene(state).paragraphs.join(''));
  }
  assert.equal(texts.size, 6);
  assert.equal(state.scene, 'escape');
  assert.equal(getScene(state).choices.length, 0);
});

test('靠近旅馆和查看物品不会增加或重置赶路次数', () => {
  const state = route('walk', 'walk', 'walk', 'approach', 'well', 'leave-well', 'ruins');
  const before = structuredClone(state);
  getScene(state); getScene(state); inspectItem(state, 'ring');
  assert.deepEqual(state, before);
  assert.equal(state.forestSteps, 3);
  assert.equal(choose(state, 'walk').forestSteps, 4);
});

test('戒指只获得一次，投井后不能重新拾取', () => {
  const state = findRing();
  assert.deepEqual(state.inventory, ['ring']);
  assert.equal(choose(state, 'take-ring'), state);
  const dropped = ['approach', 'well', 'drop-ring', 'leave-well', 'ruins'].reduce(choose, state);
  assert.equal(dropped.inventory.includes('ring'), false);
  assert.equal(dropped.flags.ringFound, true);
  assert.equal(getScene(dropped).choices.some(choice => choice.id === 'rest'), false);
  const morning = choose(dropped, 'wait-morning');
  assert.equal(getScene(morning).choices.some(choice => choice.id === 'search-ring'), false);
});

test('银钥匙隔天才出现，重复查看水井不会重复获得', () => {
  let state = ['approach', 'well', 'drop-ring', 'look-well'].reduce(choose, findRing());
  assert.equal(state.ringDroppedOnDay, 1);
  assert.equal(getScene(state).choices.some(choice => choice.id === 'pull-rope'), false);
  state = ['leave-well', 'ruins', 'wait-morning', 'approach', 'well', 'pull-rope'].reduce(choose, state);
  assert.equal(state.day, 2);
  assert.deepEqual(state.inventory, ['silverKey']);
  state = ['leave-well', 'well'].reduce(choose, state);
  assert.equal(getScene(state).choices.some(choice => choice.id === 'pull-rope'), false);
});

test('画像和门牌线索保留，重复调查不会复制画像', () => {
  let state = route('walk', 'walk', 'walk', 'wait-morning', 'house', 'ruins', 'house', 'ruins', 'doorplates');
  assert.equal(state.inventory.filter(item => item === 'portrait').length, 1);
  assert.equal(knownClues(state).length, 2);
  state = ['ruins', 'approach', 'enter'].reduce(choose, state);
  assert.ok(getScene(state).paragraphs.some(text => text.includes('眉眼')));
});

test('未持有戒指时无法投井，也不会让前台认出戒指', () => {
  const well = route('approach', 'well');
  assert.equal(choose(well, 'drop-ring'), well);
  const frontDesk = route('approach', 'enter');
  assert.equal(frontDesk.flags.emilySawRing, false);
  assert.equal(getScene(frontDesk).paragraphs.some(text => text.includes('讶异')), false);
});

test('戒指铭文需要在旅馆内主动查看，查看不推进故事或时间', () => {
  let state = findRing();
  assert.equal(inspectItem(state, 'ring'), state);
  state = ['approach', 'enter'].reduce(choose, state);
  assert.equal(state.flags.emilySawRing, true);
  assert.equal(state.flags.ringInscriptionRead, false);
  const inspected = inspectItem(state, 'ring');
  assert.equal(inspected.flags.ringInscriptionRead, true);
  assert.equal(inspected.scene, state.scene);
  assert.equal(inspected.day, state.day);
  assert.equal(inspected.forestSteps, state.forestSteps);
  assert.equal(state.flags.ringInscriptionRead, false);
});

test('新游戏独立重置全部探索状态', () => {
  const previous = findRing();
  const next = createGame();
  assert.equal(next.scene, 'arrival');
  assert.deepEqual(next.inventory, []);
  assert.equal(next.forestSteps, 0);
  assert.equal(next.flags.ringFound, false);
  assert.equal(previous.inventory.includes('ring'), true);
});

test('登记簿先显示空白退房栏，入住后查看才记录自己的名字', () => {
  let state = route('approach', 'enter', 'look-registry');
  assert.equal(state.flags.registrySeen, true);
  assert.equal(state.flags.ownEntrySeen, false);
  assert.ok(getScene(state).paragraphs.some(text => text.includes('退房日期')));
  state = ['start-check-in', 'finish-check-in'].reduce(choose, state);
  assert.equal(state.flags.checkedIn, true);
  assert.deepEqual(state.inventory, ['roomKey']);
  assert.equal(state.flags.ownEntrySeen, false);
  state = choose(state, 'look-registry');
  assert.equal(state.flags.ownEntrySeen, true);
  assert.ok(getScene(state).paragraphs.some(text => text.includes('你的名字')));
  assert.ok(knownClues(state).some(text => text.includes('你的名字')));
});

test('直接办理入住也能发现登记簿异常，钥匙不会重复领取', () => {
  let state = route('approach', 'enter', 'start-check-in');
  assert.equal(state.flags.registrySeen, true);
  assert.ok(getScene(state).paragraphs.some(text => text.includes('退房栏')));
  state = ['finish-check-in', 'back-reception', 'return-room'].reduce(choose, state);
  assert.equal(state.inventory.filter(item => item === 'roomKey').length, 1);
  assert.equal(state.scene, 'guestRoom');
});

test('第一夜调查隔壁再入睡，清晨可重访登记簿和旅馆外', () => {
  let state = route('approach', 'enter', 'start-check-in', 'finish-check-in', 'go-room', 'investigate', 'neighbor-door', 'enter-neighbor');
  assert.equal(state.flags.neighborRoomSeen, true);
  assert.ok(knownClues(state).some(text => text.includes('隔壁房门')));
  state = ['back-hallway', 'back-room', 'lie-down', 'sleep'].reduce(choose, state);
  assert.equal(state.scene, 'morningRoom');
  assert.equal(state.day, 2);
  assert.equal(state.time, 'morning');
  assert.equal(state.flags.firstNightSlept, true);
  state = ['go-reception', 'look-registry'].reduce(choose, state);
  assert.equal(state.flags.ownEntrySeen, true);
  state = ['back-reception', 'leave-inn', 'well'].reduce(choose, state);
  assert.equal(state.scene, 'well');
});

test('旅馆过夜也能让前一天投井的戒指在井绳处得到反馈', () => {
  let state = ['approach', 'well', 'drop-ring', 'leave-well', 'enter', 'start-check-in', 'finish-check-in', 'go-room', 'lie-down', 'sleep', 'go-outside', 'well'].reduce(choose, findRing());
  assert.equal(state.flags.emilySawRing, false);
  assert.equal(state.day, 2);
  assert.ok(getScene(state).choices.some(choice => choice.id === 'pull-rope'));
  state = choose(state, 'pull-rope');
  assert.deepEqual(state.inventory, ['roomKey', 'silverKey']);
});

test('清晨抵达后经前台回客房，第一夜仍从当晚开始', () => {
  const state = route('walk', 'walk', 'walk', 'wait-morning', 'approach', 'enter', 'start-check-in', 'finish-check-in', 'back-reception', 'return-room');
  assert.equal(state.day, 2);
  assert.equal(state.time, 'night');
  assert.equal(state.scene, 'guestRoom');
});
