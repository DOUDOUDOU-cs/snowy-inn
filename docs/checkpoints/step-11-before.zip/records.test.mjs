import test from 'node:test';
import assert from 'node:assert/strict';
import { getScene } from '../src/game/engine.ts';
import { emptyRecords, startJourney, recordChoice, recordItemInspection, parseRecords, openRecordStore, SAVE_KEY } from '../src/game/records.ts';

function travel(records, ...ids) {
  for (const id of ids) {
    assert.ok(getScene(records.current.state).choices.some(choice => choice.id === id), `${id} 应在 ${records.current.state.scene} 可选`);
    records = recordChoice(records, id);
  }
  return records;
}

function memoryStorage() {
  const values = new Map();
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
}

test('历史保存当时的文字及实际选择，重复阅读不会改变记录', () => {
  let records = travel(startJourney(emptyRecords()), 'walk', 'walk', 'walk', 'rest', 'take-ring', 'approach', 'enter');
  const original = structuredClone(records);
  const reception = records.current.entries.at(-1);
  assert.ok(reception.paragraphs.join('').includes('你手里的戒指'));
  records = travel(records, 'leave-inn', 'well', 'drop-ring');
  assert.equal(records.current.state.inventory.includes('ring'), false);
  assert.ok(records.current.entries[7].paragraphs.join('').includes('你手里的戒指'));
  assert.deepEqual(records.current.entries[7].choice, { id: 'leave-inn', text: '暂时走出旅馆' });
  assert.equal(original.current.entries.at(-1).choice, undefined);
  const before = JSON.stringify(records);
  getScene(records.current.state);
  getScene(records.current.state);
  assert.equal(JSON.stringify(records), before);
  assert.equal(recordChoice(records, '不存在的选项'), records);
});

test('自动保存后可恢复同一场景、物品、线索与历史，接着选择只新增一段', () => {
  const storage = memoryStorage();
  const first = openRecordStore(() => storage);
  let records = travel(startJourney(first.data), 'walk', 'walk', 'walk', 'rest', 'take-ring', 'approach', 'enter');
  const count = records.current.entries.length;
  records = recordItemInspection(records, 'ring');
  assert.equal(records.current.entries.length, count);
  assert.equal(records.current.state.flags.ringInscriptionRead, true);
  assert.equal(first.save(records), true);
  const reopened = openRecordStore(() => storage);
  assert.deepEqual(reopened.data, records);
  records = travel(reopened.data, 'start-check-in');
  assert.equal(records.current.entries.length, count + 1);
  assert.equal(records.current.state.flags.ringInscriptionRead, true);
  assert.equal(reopened.save(records), true);
});

test('重新开始保存旧旅程，通关与未完旅程都能留存且新局不继承物品', () => {
  let records = travel(startJourney(emptyRecords()), 'walk', 'walk', 'walk', 'rest', 'take-ring');
  const abandoned = structuredClone(records.current);
  records = startJourney(records);
  assert.deepEqual(records.current.state.inventory, []);
  assert.deepEqual(records.archives[0].entries, abandoned.entries);
  assert.equal(records.archives[0].state, undefined);
  records = travel(records, ...Array(10).fill('walk'));
  assert.equal(records.current.entries.at(-1).ending, '结局 · 一直向前');
  assert.equal(records.current.entries.some(entry => entry.ending === '结局 · 退房'), false);
  records = startJourney(records);
  assert.equal(records.archives.length, 2);
  assert.equal(records.archives[1].entries.at(-1).ending, '结局 · 一直向前');
  assert.deepEqual(parseRecords(JSON.stringify(records)), records);
});

test('坏档、未知版本和不完整状态不崩溃，也不被新旅程覆盖', () => {
  for (const raw of ['{broken', JSON.stringify({version: 9}), 'null']) {
    const storage = memoryStorage();
    storage.setItem(SAVE_KEY, raw);
    const store = openRecordStore(() => storage);
    assert.equal(store.data.current, null);
    assert.ok(store.message);
    assert.equal(store.save(startJourney(store.data)), false);
    assert.equal(storage.getItem(SAVE_KEY), raw);
  }
  const valid = startJourney(emptyRecords());
  for (const mutate of [
    data => { data.current.state.scene = 'missing-scene'; },
    data => { data.current.state.fusion = 500; },
    data => { data.current.state.inventory = ['unknown-item']; },
    data => { delete data.current.state.flags.choseToStay; },
    data => { data.current.entries = []; },
    data => { data.current.entries[0].scene = 'forest'; },
  ]) {
    const broken = structuredClone(valid);
    mutate(broken);
    assert.equal(parseRecords(JSON.stringify(broken)), null);
  }
});

test('存储失败时保留上次记录并提示，恢复可用后再次保存成功', () => {
  const storage = memoryStorage();
  let failing = false;
  const port = { getItem: storage.getItem, setItem: (key, raw) => { if (failing) throw new Error('quota'); storage.setItem(key, raw); } };
  const store = openRecordStore(() => port);
  let records = startJourney(store.data);
  assert.equal(store.save(records), true);
  const previous = storage.getItem(SAVE_KEY);
  failing = true;
  records = travel(records, 'walk');
  assert.equal(store.save(records), false);
  assert.ok(store.message.includes('暂未保存'));
  assert.equal(storage.getItem(SAVE_KEY), previous);
  failing = false;
  assert.equal(store.save(records), true);
  assert.equal(store.message, '');
});

test('其他窗口更新进度后不互相覆盖，读取权限错误也不使游戏崩溃', () => {
  const storage = memoryStorage();
  const first = openRecordStore(() => storage);
  const second = openRecordStore(() => storage);
  const records = startJourney(first.data);
  assert.equal(first.save(records), true);
  assert.equal(second.save(startJourney(second.data)), false);
  assert.ok(second.message.includes('另一个窗口'));
  assert.deepEqual(parseRecords(storage.getItem(SAVE_KEY)), records);
  const denied = openRecordStore(() => { throw new Error('unavailable'); });
  assert.equal(denied.data.current, null);
  assert.equal(denied.save(startJourney(denied.data)), false);
  assert.ok(denied.message);
});
