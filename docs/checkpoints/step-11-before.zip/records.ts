import { choose, getScene, inspectItem } from "./engine.ts";
import { createGame } from "./state.ts";
import { openingScenes } from "../story/opening.ts";
import { items } from "../story/items.ts";
import type { GameState, ItemId, SceneId } from "./types.ts";

export interface HistoryEntry {
  scene: SceneId;
  day: number;
  time: GameState["time"];
  location: string;
  title: string;
  paragraphs: string[];
  choice?: { id: string; text: string };
  ending?: string;
}

export interface JourneyRecord {
  id: string;
  startedAt: string;
  updatedAt: string;
  entries: HistoryEntry[];
}

export interface CurrentJourney extends JourneyRecord { state: GameState }
export interface GameRecords {
  version: 1;
  current: CurrentJourney | null;
  archives: JourneyRecord[];
}

export const emptyRecords = (): GameRecords => ({ version: 1, current: null, archives: [] });

// 保存当时实际呈现的文字，而不是回看时用新的物品、天数重新生成剧情。
function captureScene(state: GameState): HistoryEntry {
  const scene = getScene(state);
  return {
    scene: state.scene, day: state.day, time: state.time,
    location: scene.location, title: scene.title, paragraphs: [...scene.paragraphs],
    ...(scene.ending ? { ending: scene.ending } : {}),
  };
}

export function startJourney(records: GameRecords, now = new Date().toISOString()): GameRecords {
  const state = createGame();
  const archives = [...records.archives];
  if (records.current) {
    const { state: _state, ...archive } = records.current;
    archives.push(archive);
  }
  return {
    version: 1, archives,
    current: {
      id: `${now}-${Math.random().toString(36).slice(2, 10)}`,
      startedAt: now, updatedAt: now, state, entries: [captureScene(state)],
    },
  };
}

export function recordChoice(records: GameRecords, choiceId: string, now = new Date().toISOString()): GameRecords {
  const current = records.current;
  if (!current) return records;
  const choice = getScene(current.state).choices.find(candidate => candidate.id === choiceId);
  if (!choice) return records;
  const state = choose(current.state, choiceId);
  const entries = current.entries.map((entry, index) => index === current.entries.length - 1
    ? { ...entry, choice: { id: choice.id, text: choice.text } } : entry);
  entries.push(captureScene(state));
  return { ...records, current: { ...current, state, entries, updatedAt: now } };
}

export function recordItemInspection(records: GameRecords, item: ItemId): GameRecords {
  if (!records.current) return records;
  const state = inspectItem(records.current.state, item);
  if (state === records.current.state) return records;
  return { ...records, current: { ...records.current, state, updatedAt: new Date().toISOString() } };
}

const isObject = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);
const isDay = (value: unknown): value is number => typeof value === "number" && Number.isSafeInteger(value) && value >= 1;
const isTime = (value: unknown) => value === "night" || value === "morning";
const isScene = (value: unknown): value is SceneId => typeof value === "string" && Object.prototype.hasOwnProperty.call(openingScenes, value);
const isDate = (value: unknown) => typeof value === "string" && Number.isFinite(Date.parse(value));

function isState(value: unknown): value is GameState {
  if (!isObject(value) || !isScene(value.scene) || !isDay(value.day) || !isTime(value.time)) return false;
  if (!Number.isInteger(value.forestSteps) || (value.forestSteps as number) < 0 || (value.forestSteps as number) > 10) return false;
  if (!Number.isInteger(value.fusion) || (value.fusion as number) < 0 || (value.fusion as number) > 6) return false;
  if (!Array.isArray(value.inventory) || !value.inventory.every(item => typeof item === "string" && Object.prototype.hasOwnProperty.call(items, item)) || new Set(value.inventory).size !== value.inventory.length) return false;
  if (value.ringDroppedOnDay !== null && (!isDay(value.ringDroppedOnDay) || value.ringDroppedOnDay > value.day)) return false;
  if (!["unresolved", "eaten", "pretended", "declined"].includes(value.breakfast as string)) return false;
  const flags = value.flags;
  return isObject(flags) && Object.keys(createGame().flags).every(key => typeof flags[key] === "boolean");
}

function isEntry(value: unknown): value is HistoryEntry {
  if (!isObject(value) || !isScene(value.scene) || !isDay(value.day) || !isTime(value.time)) return false;
  if (typeof value.location !== "string" || typeof value.title !== "string" || !Array.isArray(value.paragraphs) || !value.paragraphs.every(text => typeof text === "string")) return false;
  if (value.ending !== undefined && typeof value.ending !== "string") return false;
  return value.choice === undefined || (isObject(value.choice) && typeof value.choice.id === "string" && typeof value.choice.text === "string");
}

function isJourney(value: unknown): value is JourneyRecord {
  return isObject(value) && typeof value.id === "string" && isDate(value.startedAt) && isDate(value.updatedAt)
    && Array.isArray(value.entries) && value.entries.length > 0 && value.entries.every(isEntry);
}

export function parseRecords(raw: string): GameRecords | null {
  try {
    const data: unknown = JSON.parse(raw);
    if (!isObject(data) || data.version !== 1 || !Array.isArray(data.archives) || !data.archives.every(isJourney)) return null;
    if (data.current !== null) {
      const current = data.current;
      if (!isJourney(current) || !isObject(current) || !isState(current.state)) return null;
      const last = current.entries[current.entries.length - 1]!;
      if (last.scene !== current.state.scene || last.day !== current.state.day || last.time !== current.state.time || last.choice !== undefined) return null;
    }
    return data as unknown as GameRecords;
  } catch { return null; }
}

export const SAVE_KEY = "snow-inn.records.v1";
type StoragePort = Pick<Storage, "getItem" | "setItem">;

// 损坏/未来版本记录保留原样；其他窗口写入时也不覆盖它的进度。
export function openRecordStore(getStorage: () => StoragePort) {
  let original: string | null = null;
  let blocked = false;
  let message = "";
  let data = emptyRecords();
  try {
    original = getStorage().getItem(SAVE_KEY);
    if (original !== null) {
      const parsed = parseRecords(original);
      if (parsed) data = parsed;
      else {
        blocked = true;
        message = "本机记录暂时无法读取，原数据已保留。当前游玩不会覆盖它，也暂时无法保存。";
      }
    }
  } catch {
    message = "当前无法读取本机记录。可以游玩，但进度可能无法保存。";
  }
  return {
    data,
    get message() { return message; },
    save(records: GameRecords): boolean {
      if (blocked) return false;
      try {
        const storage = getStorage();
        if (storage.getItem(SAVE_KEY) !== original) {
          message = "另一个窗口更新了记录，本窗口的新进度暂未保存。请勿关闭本窗口，以免丢失这段进度。";
          return false;
        }
        const raw = JSON.stringify(records);
        storage.setItem(SAVE_KEY, raw);
        original = raw;
        message = "";
        return true;
      } catch {
        message = "本次进度暂未保存，请勿关闭或刷新窗口。下一次选择时会再次尝试保存。";
        return false;
      }
    },
  };
}
