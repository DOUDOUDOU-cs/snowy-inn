export type SceneId = "arrival" | "forest" | "ruins" | "tiredSearch" | "ringFind" | "portrait" | "doorplates" | "entrance" | "well" | "ringDropped" | "silverKey" | "reception" | "hallPortrait" | "registry" | "checkIn" | "keyHandover" | "guestRoom" | "nightNoise" | "hallway" | "neighborDoor" | "neighborRoom" | "morningRoom" | "wardrobe" | "cabinet" | "photoFind" | "basementDoor" | "basementStairs" | "basementShore" | "breakfastOffer" | "breakfastPlate" | "breakfastInspect" | "breakfastResult" | "groundHall" | "kitchenThreshold" | "deskDrawer" | "escape";
export type ItemId = "ring" | "portrait" | "silverKey" | "roomKey" | "oldLedger" | "bronzeKey" | "adultPhoto";

export interface GameState {
  scene: SceneId;
  day: number;
  time: "night" | "morning";
  forestSteps: number;
  inventory: ItemId[];
  ringDroppedOnDay: number | null;
  fusion: number;
  breakfast: "unresolved" | "eaten" | "pretended" | "declined";
  flags: {
    ringFound: boolean;
    portraitSeen: boolean;
    doorplatesSeen: boolean;
    ruinsSeen: boolean;
    enteredInn: boolean;
    emilySawRing: boolean;
    ringInscriptionRead: boolean;
    registrySeen: boolean;
    checkedIn: boolean;
    ownEntrySeen: boolean;
    hallPortraitSeen: boolean;
    neighborRoomSeen: boolean;
    firstNightSlept: boolean;
    foodExamined: boolean;
    basementUnlocked: boolean;
    peacefulSleepUsed: boolean;
  };
}

export interface Choice {
  id: string;
  text: string;
  next: SceneId | ((state: GameState) => SceneId);
  available?: (state: GameState) => boolean;
  apply?: (state: GameState) => GameState;
}

export interface Scene {
  location: string;
  title: string;
  paragraphs: string[];
  choices: Choice[];
  previewEnd?: string;
  ending?: string;
}
