import { choose, getScene, inspectItem } from "./game/engine";
import { createGame, knownClues } from "./game/state";
import type { GameState, ItemId } from "./game/types";
import { items } from "./story/items";

const root = document.querySelector<HTMLElement>("#app");
if (!root) throw new Error("找不到游戏显示区域 #app。");
const app: HTMLElement = root;
let game: GameState | null = null;
let feedback = "";

// 只在开始新游戏时重置；切换到标题、物品页都保留本次探索进度。
function startGame(): void { game = createGame(); feedback = ""; renderStory(); }
function focusHeading(): void {
  window.scrollTo({ top: 0, behavior: "instant" });
  app.querySelector<HTMLElement>("h1")!.focus({ preventScroll: true });
}
function textButton(text: string, action: () => void, className = "text-button"): HTMLButtonElement {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className;
  button.textContent = text;
  button.addEventListener("click", action);
  return button;
}
function addParagraphs(target: HTMLElement, paragraphs: string[]): void {
  for (const text of paragraphs) {
    const paragraph = document.createElement("p");
    paragraph.textContent = text;
    target.append(paragraph);
  }
}

function renderTitle(): void {
  const canResume = game !== null && game.scene !== "escape";
  app.innerHTML = `
    <section class="title-screen screen" aria-labelledby="game-title">
      <p class="eyebrow">一八六〇年 · 冬</p>
      <h1 id="game-title" tabindex="-1">雪夜旅馆</h1>
      <p class="title-description">漫长的风雪里，<br>终于有一扇窗，还亮着灯。</p>
      <div class="title-actions"></div>
      <p class="edition">探索试玩 · 暂不存档</p>
    </section>`;
  const actions = app.querySelector<HTMLElement>(".title-actions")!;
  actions.append(textButton(canResume ? "继续探索 →" : "开始游戏 →", canResume ? renderStory : startGame, "start-button"));
  if (canResume) actions.append(textButton("重新开始", renderRestartPrompt));
  focusHeading();
}

function renderRestartPrompt(): void {
  app.innerHTML = `
    <section class="story-screen screen" aria-labelledby="restart-title">
      <p class="eyebrow">重新开始</p>
      <h1 id="restart-title" tabindex="-1">再走一次这条路？</h1>
      <div class="narrative"><p>重新开始会清除本次获得的物品和探索进度。</p></div>
      <div class="choices"></div>
    </section>`;
  const buttons = app.querySelector<HTMLElement>(".choices")!;
  buttons.append(textButton("保留进度，返回标题", renderTitle, "choice-button"), textButton("确认重新开始", startGame, "choice-button"));
  focusHeading();
}

function renderStory(): void {
  if (!game) return renderTitle();
  const snapshot = game;
  const scene = getScene(snapshot);
  app.innerHTML = `
    <section class="story-screen screen" aria-labelledby="scene-title">
      <nav class="story-nav" aria-label="游戏导航">
        <button class="text-button" id="back-title" type="button">← 返回标题</button>
        <span class="story-time"></span>
        <button class="text-button" id="inventory" type="button"></button>
      </nav>
      <p class="eyebrow scene-location"></p>
      <h1 id="scene-title" tabindex="-1"></h1>
      <div class="narrative"></div>
      <div class="choices" role="group" aria-label="选择下一步"></div>
    </section>`;
  app.querySelector<HTMLElement>(".story-time")!.textContent = snapshot.time === "night" ? "雪夜" : "次日清晨";
  app.querySelector<HTMLElement>(".scene-location")!.textContent = scene.location;
  app.querySelector<HTMLElement>("h1")!.textContent = scene.title;
  const inventoryButton = app.querySelector<HTMLButtonElement>("#inventory")!;
  inventoryButton.textContent = "随身物品（" + snapshot.inventory.length + "）";
  inventoryButton.addEventListener("click", renderInventory);
  app.querySelector<HTMLButtonElement>("#back-title")!.addEventListener("click", renderTitle);
  addParagraphs(app.querySelector<HTMLElement>(".narrative")!, scene.paragraphs);
  if (feedback) {
    const message = document.createElement("p");
    message.className = "item-feedback";
    message.setAttribute("role", "status");
    message.textContent = feedback;
    app.querySelector<HTMLElement>(".narrative")!.append(message);
    feedback = "";
  }
  const choices = app.querySelector<HTMLElement>(".choices")!;
  for (const choice of scene.choices) {
    const button = textButton("", () => {
      // 忽略来自旧画面的点击，避免同一次拾取被执行两遍。
      if (game !== snapshot) return;
      button.disabled = true;
      game = choose(snapshot, choice.id);
      const added = game.inventory.filter(item => !snapshot.inventory.includes(item));
      feedback = added.length ? "已收好：" + added.map(item => items[item].name).join("、")
        : hasLostRing(snapshot, game) ? "戒指已留在井里。" : "";
      renderStory();
    }, "choice-button");
    const label = document.createElement("span");
    label.textContent = choice.text;
    const arrow = document.createElement("span");
    arrow.textContent = "→";
    arrow.setAttribute("aria-hidden", "true");
    button.append(label, arrow);
    choices.append(button);
  }
  if (scene.previewEnd || scene.ending) {
    const note = document.createElement("aside");
    note.className = "preview-end";
    addParagraphs(note, [scene.previewEnd ?? scene.ending!]);
    if (scene.ending) note.append(textButton("重新踏上旅程 →", startGame));
    choices.append(note);
  }
  focusHeading();
}

function renderInventory(): void {
  if (!game) return renderTitle();
  app.innerHTML = `
    <section class="story-screen screen" aria-labelledby="inventory-title">
      <nav class="story-nav"><button class="text-button" type="button">← 返回探索</button><span>随身记录</span></nav>
      <p class="eyebrow">旅途中留下的东西</p>
      <h1 id="inventory-title" tabindex="-1">随身物品</h1>
      <div class="item-list choices" role="group" aria-label="查看物品"></div>
      <section class="clue-list" aria-labelledby="clue-title"><h2 id="clue-title">记下的线索</h2><div></div></section>
    </section>`;
  app.querySelector<HTMLButtonElement>("nav button")!.addEventListener("click", renderStory);
  const list = app.querySelector<HTMLElement>(".item-list")!;
  if (game.inventory.length === 0) addParagraphs(list, ["还没有收集到物品。"]);
  for (const item of game.inventory) list.append(textButton(items[item].name + " →", () => renderItem(item), "choice-button"));
  const clues = knownClues(game);
  addParagraphs(app.querySelector<HTMLElement>(".clue-list div")!, clues.length ? clues : ["还没有记下线索。"]);
  focusHeading();
}

function renderItem(item: ItemId): void {
  if (!game || !game.inventory.includes(item)) return renderInventory();
  game = inspectItem(game, item);
  app.innerHTML = `
    <section class="story-screen screen" aria-labelledby="item-title">
      <nav class="story-nav"><button class="text-button" type="button">← 返回随身物品</button><span>仔细查看</span></nav>
      <p class="eyebrow">随身物品</p>
      <h1 id="item-title" tabindex="-1"></h1>
      <div class="narrative"></div>
    </section>`;
  app.querySelector<HTMLButtonElement>("nav button")!.addEventListener("click", renderInventory);
  app.querySelector<HTMLElement>("h1")!.textContent = items[item].name;
  addParagraphs(app.querySelector<HTMLElement>(".narrative")!, items[item].description(game));
  focusHeading();
}

renderTitle();

function hasLostRing(before: GameState, after: GameState): boolean {
  return before.inventory.includes("ring") && !after.inventory.includes("ring");
}
