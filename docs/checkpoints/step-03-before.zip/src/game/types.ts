export type SceneId = "arrival" | "forest" | "ruins" | "tiredSearch" | "ringFind" | "portrait" | "doorplates" | "entrance" | "well" | "ringDropped" | "silverKey" | "reception" | "escape";
export type ItemId = "ring" | "portrait" | "silverKey";

export interface GameState {
  scene: SceneId;
  day: number;
  time: "night" | "morning";
  forestSteps: number;
  inventory: ItemId[];
  ringDroppedOnDay: number | null;
  flags: {
    ringFound: boolean;
    portraitSeen: boolean;
    doorplatesSeen: boolean;
    ruinsSeen: boolean;
    enteredInn: boolean;
    emilySawRing: boolean;
    ringInscriptionRead: boolean;
  };
}

export interface Choice {
  id: string;
  text: string;
  next: SceneId | ((state: GameState) => SceneId);
  available?: (state: GameState) => boolean;
  apply?: (state: GameState) => GameState;
}

export interface Scene {
  location: string;
  title: string;
  paragraphs: string[];
  choices: Choice[];
  previewEnd?: string;
  ending?: string;
}
