import type { GameState, ItemId } from "./types.ts";

export function createGame(): GameState {
  return {
    scene: "arrival", day: 1, time: "night", forestSteps: 0,
    inventory: [], ringDroppedOnDay: null,
    flags: {
      ringFound: false, portraitSeen: false, doorplatesSeen: false,
      ruinsSeen: false, enteredInn: false, emilySawRing: false, ringInscriptionRead: false,
    },
  };
}

export function hasItem(state: GameState, item: ItemId): boolean {
  return state.inventory.includes(item);
}

export function addItem(state: GameState, item: ItemId): GameState {
  return hasItem(state, item) ? state : { ...state, inventory: [...state.inventory, item] };
}

export function knownClues(state: GameState): string[] {
  const clues: string[] = [];
  if (state.flags.portraitSeen) clues.push("全家福画像背面写着“艾米莉”，年份是 1682。");
  if (state.flags.doorplatesSeen) clues.push("遗迹中有“爱德华与艾米莉之家”的门牌。");
  if (state.flags.ringInscriptionRead) clues.push("戒指内侧刻着：艾米莉，I love you forever。");
  return clues;
}
