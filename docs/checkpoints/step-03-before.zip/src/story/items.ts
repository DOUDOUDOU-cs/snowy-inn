import type { GameState, ItemId } from "../game/types.ts";

export const items: Record<ItemId, { name: string; description: (state: GameState) => string[] }> = {
  ring: {
    name: "戒指",
    description: state => state.flags.enteredInn
      ? ["你将戒指凑近旅馆的灯光。内侧有一行极细小的字迹：", "艾米莉，I love you forever。"]
      : ["从村庄遗迹里拾到的戒指，表面沾着一点泥土。", "内侧似乎刻着字，可这里光线太暗，暂时看不清。"],
  },
  portrait: {
    name: "全家福画像",
    description: () => ["一幅从半塌的小屋中找到的小画像，画中人笑得很幸福。", "画框背面有稚嫩的笔迹：艾米莉的全家福，1682。"],
  },
  silverKey: {
    name: "银白色钥匙",
    description: () => ["从井中的木桶里取出的钥匙。表面温润，看不出明显的锈迹。", "你还不知道它能打开哪一扇门。"],
  },
};
