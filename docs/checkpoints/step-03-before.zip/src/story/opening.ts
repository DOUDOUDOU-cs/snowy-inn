import { addItem, hasItem } from "../game/state.ts";
import type { Choice, GameState, Scene, SceneId } from "../game/types.ts";

// 这里只放剧情、选项和发生效果的时机；字号与背景在样式和页面入口中维护。
const walk: Choice = {
  id: "walk", text: "继续行进",
  apply: state => ({ ...state, forestSteps: Math.min(10, state.forestSteps + 1) }),
  next: state => state.forestSteps >= 10 && !state.flags.enteredInn ? "escape" : state.forestSteps === 3 ? "ruins" : "forest",
};
const toInn: Choice = { id: "approach", text: "向旅馆走去", next: "entrance" };
const toRuins: Choice = { id: "ruins", text: "回到村庄遗迹", next: "ruins" };

const forestParagraphs: Record<number, string[]> = {
  1: ["你收回目光，继续向森林深处走去。", "暗夜的密林和乌鸦的叫声，逐渐扰乱了你的判断。你已经说不清自己走了多久。", "模模糊糊中，前方又出现了那间旅馆。"],
  2: ["你绕开路边折断的树枝，又走了很远。", "灯光再次浮现在树影之间。那根折断的树枝，就在你的脚边。"],
  4: ["你沿着另一侧的林缘走去。", "雪地里留着一串脚印。你停下比了比，鞋底的缺口和你的完全一样。"],
  5: ["乌鸦从树枝上飞起，落向前方。", "走近后，你看见那棵树上仍蹲着一只乌鸦，脚下压着同一根弯曲的枝条。"],
  6: ["你选了背对灯光的方向。", "走过一段缓坡，窗里的光却从正前方照了过来。"],
  7: ["一块歪斜的路牌立在雪里，字迹已经磨损。", "你从左侧绕过去。再次碰到它时，牌面朝向了相反的方向。"],
  8: ["你低下头，只盯着自己的脚步。", "鞋尖踢到一根折断的树枝。你还记得它的形状。"],
  9: ["旅馆又出现在前面，窗户里的光依然温暖。", "你没有停下。风把身后的脚印一点点填平。"],
};

export const openingScenes: Record<SceneId, (state: GameState) => Scene> = {
  arrival: () => ({
    location: "森林边缘", title: "风雪中的灯光",
    paragraphs: ["1860 年的一个雪夜。经过长途跋涉，你的脚步已经越来越沉。", "风穿过暗处的树枝。前方，一间旅馆的窗户透出昏黄的灯光。", "你在路边停了下来。"],
    choices: [toInn, { ...walk, text: "不顾疲惫，继续赶路" }],
  }),
  forest: state => ({
    location: "林间小路", title: state.time === "morning" ? "林间的旧路" : "又一盏熟悉的灯",
    paragraphs: state.time === "morning"
      ? ["天色已经亮了，你沿着林间的路继续走。", ...(forestParagraphs[state.forestSteps] ?? ["穿过树影，那间旅馆仍然出现在道路尽头。"]).slice(-1)]
      : forestParagraphs[state.forestSteps] ?? ["穿过树影，那间旅馆仍然出现在道路尽头。"],
    choices: [toInn, walk, { ...toRuins, available: current => current.forestSteps >= 3 }],
  }),
  ruins: state => ({
    location: "村庄遗迹", title: state.time === "night" ? "雪下的石头" : "荒废的村庄",
    paragraphs: state.time === "night"
      ? ["林木之间，你看见了不一样的东西：几块墓碑，以及石材制成的村庄残骸。", "墙体大半已经坍塌。你靠近一处背风的角落，疲惫让视线有些模糊。"]
      : ["天亮后，遗迹的轮廓逐渐清楚。这片地方以前似乎是一座村庄。", "几栋小屋已经半塌，门牌或悬挂在墙上，或落在积雪里。"],
    choices: state.time === "night" ? [
      { id: "search", text: "强撑着调查一番", next: "tiredSearch" },
      { id: "rest", text: "稍作休息，再搜寻附近", next: "ringFind", available: current => !current.flags.ringFound },
      { id: "wait-morning", text: "在背风处休息到天亮", next: "ruins", apply: current => ({ ...current, day: current.day + 1, time: "morning", flags: { ...current.flags, ruinsSeen: true } }) },
      walk, toInn,
    ] : [
      { id: "house", text: state.flags.portraitSeen ? "再看看半塌的小屋" : "调查半塌的小屋", next: "portrait", apply: current => ({ ...addItem(current, "portrait"), flags: { ...current.flags, portraitSeen: true, ruinsSeen: true } }) },
      { id: "doorplates", text: "查看散落的门牌", next: "doorplates", apply: current => ({ ...current, flags: { ...current.flags, doorplatesSeen: true, ruinsSeen: true } }) },
      { id: "search-ring", text: "查看废墟中的亮点", next: "ringFind", available: current => !current.flags.ringFound },
      walk, toInn,
    ],
  }),
  tiredSearch: () => ({
    location: "村庄遗迹", title: "疲惫的侵扰",
    paragraphs: ["你试着沿墙摸索，可只能模模糊糊地感到石头硌着手掌。", "眼下的疲惫，让你无法再仔细分辨这里的东西。"],
    choices: [{ id: "rest", text: "先找个背风的地方休息", next: "ruins" }, toInn],
  }),
  ringFind: state => ({
    location: "村庄遗迹", title: "碎木之间的微光",
    paragraphs: state.flags.ringFound
      ? ["碎木之间已经没有别的东西了。"]
      : ["稍微缓过气来后，你俯下身，仔细搜寻附近。", "几片木头碎渣之间，有一枚戒指闪着微光。"],
    choices: [
      { id: "take-ring", text: "拾起戒指", next: "ruins", available: current => !current.flags.ringFound, apply: current => ({ ...addItem(current, "ring"), flags: { ...current.flags, ringFound: true } }) },
      { id: "leave-ring", text: "回到遗迹旁", next: "ruins" },
    ],
  }),
  portrait: () => ({
    location: "半塌的小屋", title: "画中的一家人",
    paragraphs: ["你走进一间半塌的小屋。地上的碎石下面，掩埋着一幅小小的全家福画像。", "你轻轻拾起它。画中人笑得很幸福，画框背面有稚嫩的笔迹：", "艾米莉的全家福，1682。", "你将画像收好，记下了这个名字和年份。"],
    choices: [toRuins],
  }),
  doorplates: () => ({
    location: "村庄遗迹", title: "留下来的名字",
    paragraphs: ["爱德华与艾米莉之家。劳埃德的陋室。山姆的肉铺……", "你逐一辨认门牌上的字迹，把还能看清的名字记了下来。"],
    choices: [toRuins],
  }),
  entrance: state => ({
    location: "旅馆外", title: "孤零零的旅馆",
    paragraphs: ["旅馆的规模不小，周围却看不到完整的村庄。门边不远处，有几口水井。", ...(state.flags.ruinsSeen ? ["想起那片村庄遗迹，你忽然觉得水井离旅馆太近了。"] : []), "再往前，就是旅馆的门。"],
    choices: [
      { id: "well", text: "走近水井看看", next: "well" },
      { id: "enter", text: "进入旅馆", next: "reception", apply: current => ({ ...current, flags: { ...current.flags, enteredInn: true, emilySawRing: current.flags.emilySawRing || hasItem(current, "ring") } }) },
      { ...walk, text: "离开门前，继续赶路" },
      { ...toRuins, available: current => current.forestSteps >= 3 },
    ],
  }),
  well: state => {
    const keyReady = state.ringDroppedOnDay !== null && state.day > state.ringDroppedOnDay && !hasItem(state, "silverKey");
    return {
      location: "旅馆外 · 水井", title: keyReady ? "绷紧的井绳" : "平静的井水",
      paragraphs: [
        "井壁由石砖砌成，上面很潮湿，长满了苔藓。水面平静，看不出异样。",
        ...(state.time === "morning" ? ["天光下，你发现藤蔓已经爬到接近井沿的位置，像是很久没有人打理。"] : []),
        ...(keyReady ? ["井绳似乎被什么东西拉得很紧。"] : []),
      ],
      choices: [
        { id: "drop-ring", text: "把戒指丢下去试试", next: "ringDropped", available: current => hasItem(current, "ring"), apply: current => ({ ...current, inventory: current.inventory.filter(item => item !== "ring"), ringDroppedOnDay: current.day }) },
        { id: "pull-rope", text: "拉动井绳", next: "silverKey", available: () => keyReady, apply: current => addItem(current, "silverKey") },
        { id: "leave-well", text: "回到旅馆门前", next: "entrance" },
      ],
    };
  },
  ringDropped: () => ({
    location: "旅馆外 · 水井", title: "什么也没发生",
    paragraphs: ["你松开手，戒指坠入井中。", "你等了一会儿。什么也没发生。"],
    choices: [{ id: "look-well", text: "再看看水井", next: "well" }, { id: "leave-well", text: "回到旅馆门前", next: "entrance" }],
  }),
  silverKey: () => ({
    location: "旅馆外 · 水井", title: "木桶里的钥匙",
    paragraphs: ["木桶被慢慢拉了上来。里面没有水，只有一枚温润的银白色钥匙。", "你取出钥匙，放进随身物品里。"],
    choices: [{ id: "leave-well", text: "回到旅馆门前", next: "entrance" }],
  }),
  reception: state => ({
    location: "旅馆前台", title: "门内的暖意",
    paragraphs: [
      "你推开旅馆的门，把风雪留在身后。前台的桌子后面，挂着一幅很大的肖像画。",
      "“还有空房吗？”",
      "前台的小姐抬起头：“……当然。”",
      ...(state.flags.portraitSeen ? ["她的眉眼，让你想起画像里那个叫艾米莉的孩子。"] : []),
      ...(state.flags.emilySawRing ? ["她的目光扫过你手里的戒指，脸上浮现了一瞬讶异，很快又恢复了原样。"] : []),
    ],
    choices: [],
    previewEnd: "这一轮试玩到前台为止。你可以在灯下查看随身物品，或返回标题重新探索；旅馆内部将在下一步接上。",
  }),
  escape: state => ({
    location: "森林之外", title: "你确实离开了这片森林",
    paragraphs: [
      "你继续走，没有再向那盏灯靠近。",
      "脚下的道路渐渐开阔。等你再次回过头，身后只剩下树木，那间旅馆没有再出现。",
      state.time === "morning" ? "晨光落在前方的路上。你继续赶路。" : "风雪还在下。你把衣领拉紧，继续赶路。",
    ],
    choices: [],
    ending: "结局 · 一直向前",
  }),
};
