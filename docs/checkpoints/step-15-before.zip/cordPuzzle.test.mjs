import test from 'node:test';
import assert from 'node:assert/strict';
import { initialCordOrder, swapCordEnds, cordsUntangled } from '../src/game/cordPuzzle.ts';

test('衣柜绳线一开始交叉，交换绳端两次后才能理顺', () => {
  assert.equal(cordsUntangled(initialCordOrder), false);
  const first = swapCordEnds(initialCordOrder, 0, 1);
  assert.deepEqual(first, [0, 2, 1]);
  assert.equal(cordsUntangled(first), false);
  const solved = swapCordEnds(first, 1, 2);
  assert.deepEqual(solved, [0, 1, 2]);
  assert.equal(cordsUntangled(solved), true);
  assert.deepEqual(initialCordOrder, [2, 0, 1]);
  assert.equal(swapCordEnds(solved, 1, 9), solved);
});
