export type CordId = 0 | 1 | 2;
export type CordOrder = readonly [CordId, CordId, CordId];

// 数组位置是下方木钉从左到右；数字表示连到上方哪个木钉。
export const initialCordOrder: CordOrder = [2, 0, 1];

export function swapCordEnds(order: CordOrder, from: number, to: number): CordOrder {
  if (!Number.isInteger(from) || !Number.isInteger(to) || from < 0 || from > 2 || to < 0 || to > 2) return order;
  if (from === to) return order;
  const next: [CordId, CordId, CordId] = [...order];
  [next[from], next[to]] = [next[to], next[from]];
  return next;
}

export function cordsUntangled(order: CordOrder): boolean {
  return order.every((cord, slot) => cord === slot);
}
