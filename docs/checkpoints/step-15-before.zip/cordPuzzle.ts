import { cordsUntangled, initialCordOrder, swapCordEnds } from "../game/cordPuzzle";
import type { CordId, CordOrder } from "../game/cordPuzzle";

const names = ["朱红", "青绿", "琥珀"] as const;
const colors = ["#ed6255", "#53d895", "#edbd62"] as const;
const pegX = [80, 200, 320] as const;

export function openCordPuzzle(trigger: HTMLButtonElement, onSolved: () => void): void {
  const dialog = document.createElement("dialog");
  dialog.className = "puzzle-dialog cord-dialog";
  dialog.setAttribute("aria-labelledby", "cord-puzzle-title");
  dialog.setAttribute("aria-describedby", "cord-puzzle-hint");
  dialog.innerHTML = `
    <div class="puzzle-heading">
      <div>
        <p class="puzzle-eyebrow">隔壁客房 · 衣柜内侧</p>
        <h2 id="cord-puzzle-title">缠在一起的绳端</h2>
      </div>
      <button class="puzzle-close" type="button" aria-label="收起衣柜画面">×</button>
    </div>
    <p class="puzzle-description">上端系在木板上。挪动下方的绳端，让三根绳子不再交叉。</p>
    <div class="cord-board" role="group" aria-label="三根交错的绳子">
      <svg class="cord-svg" viewBox="0 0 400 300" preserveAspectRatio="none" aria-hidden="true">
        <g class="cord-pegs"></g><g class="cord-lines"></g>
      </svg>
      <button class="cord-key" type="button" aria-label="取下露出的古铜色钥匙" disabled><span class="cord-key-shape" aria-hidden="true"></span></button>
      <div class="cord-handles"></div>
    </div>
    <p class="puzzle-hint" id="cord-puzzle-hint" role="status">拖动下方的彩色绳端，或依次点选两端交换位置。</p>
    <p class="puzzle-footnote">方向键也能移动绳端。按 Esc 可返回房间。</p>`;

  const board = dialog.querySelector<HTMLElement>(".cord-board")!;
  const pegs = dialog.querySelector<SVGGElement>(".cord-pegs")!;
  const lines = dialog.querySelector<SVGGElement>(".cord-lines")!;
  const handles = dialog.querySelector<HTMLElement>(".cord-handles")!;
  const key = dialog.querySelector<HTMLButtonElement>(".cord-key")!;
  const hint = dialog.querySelector<HTMLElement>(".puzzle-hint")!;
  let order: CordOrder = [...initialCordOrder];
  let selected: CordId | null = null;
  let dragging: { cord: CordId; from: number; pointer: number; startX: number; startY: number; x: number; y: number; moved: boolean } | null = null;

  pegs.innerHTML = pegX.map((x, index) => `<circle cx="${x}" cy="42" r="17" fill="#182630" stroke="${colors[index]}" stroke-width="7"/><circle cx="${x}" cy="250" r="17" fill="#182630" stroke="#8f9b9a" stroke-width="5"/>`).join("");

  const buttons = names.map((name, cord) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "cord-handle";
    button.style.setProperty("--cord-color", colors[cord]);
    button.dataset.cord = String(cord);
    button.setAttribute("aria-label", `${name}绳端`);
    handles.append(button);
    return button;
  });

  function point(event: PointerEvent): { x: number; y: number } {
    const rect = board.getBoundingClientRect();
    return {
      x: Math.max(25, Math.min(375, (event.clientX - rect.left) / rect.width * 400)),
      y: Math.max(55, Math.min(275, (event.clientY - rect.top) / rect.height * 300)),
    };
  }

  function render(): void {
    lines.innerHTML = order.map((cord, slot) => {
      const end = dragging?.cord === cord ? { x: dragging.x, y: dragging.y } : { x: pegX[slot], y: 250 };
      const path = `M ${pegX[cord]} 42 C ${pegX[cord]} 124, ${end.x} 169, ${end.x} ${end.y}`;
      return `<path d="${path}" stroke="#111b22" stroke-width="22" fill="none" stroke-linecap="round"/><path d="${path}" stroke="${colors[cord]}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="${path}" stroke="#ffffff55" stroke-width="3" fill="none" stroke-linecap="round"/>`;
    }).join("");
    buttons.forEach((button, cord) => {
      const slot = order.indexOf(cord as CordId);
      const x = dragging?.cord === cord ? dragging.x : pegX[slot];
      const y = dragging?.cord === cord ? dragging.y : 250;
      button.style.left = `${x / 4}%`;
      button.style.top = `${y / 3}%`;
      button.classList.toggle("is-selected", selected === cord);
      button.classList.toggle("is-dragging", dragging?.cord === cord);
      button.disabled = cordsUntangled(order);
      button.setAttribute("aria-label", `${names[cord]}绳端，当前在下方第 ${slot + 1} 个木钉${selected === cord ? "，已选中" : ""}`);
    });
    const solved = cordsUntangled(order);
    dialog.classList.toggle("cord-solved", solved);
    key.disabled = !solved;
    if (solved) hint.textContent = "绳子已经理顺。现在可以取下钥匙。";
  }

  function swap(from: number, to: number): void {
    order = swapCordEnds(order, from, to);
    selected = null;
    hint.textContent = "绳端换了位置，再看看哪里还压在一起。";
    render();
    if (cordsUntangled(order)) key.focus({ preventScroll: true });
  }

  function select(cord: CordId): void {
    if (cordsUntangled(order)) return;
    if (selected === null) {
      selected = cord;
      hint.textContent = `已拿起${names[cord]}绳端。再点另一根绳端，就能交换木钉。`;
      render();
    } else if (selected === cord) {
      selected = null;
      hint.textContent = "绳端放回原位。";
      render();
    } else swap(order.indexOf(selected), order.indexOf(cord));
  }

  buttons.forEach((button, id) => {
    const cord = id as CordId;
    button.addEventListener("pointerdown", event => {
      if (cordsUntangled(order)) return;
      event.preventDefault();
      button.setPointerCapture(event.pointerId);
      const from = order.indexOf(cord);
      dragging = { cord, from, pointer: event.pointerId, startX: event.clientX, startY: event.clientY, x: pegX[from], y: 250, moved: false };
    });
    button.addEventListener("pointermove", event => {
      if (!dragging || dragging.pointer !== event.pointerId || dragging.cord !== cord) return;
      if (Math.hypot(event.clientX - dragging.startX, event.clientY - dragging.startY) > 7) dragging.moved = true;
      if (dragging.moved) {
        const position = point(event);
        dragging.x = position.x;
        dragging.y = position.y;
        render();
      }
    });
    button.addEventListener("pointerup", event => {
      if (!dragging || dragging.pointer !== event.pointerId || dragging.cord !== cord) return;
      const { from, moved } = dragging;
      dragging = null;
      if (moved) {
        const x = point(event).x;
        const to = pegX.reduce((best, peg, slot) => Math.abs(peg - x) < Math.abs(pegX[best] - x) ? slot : best, 0);
        swap(from, to);
      } else select(cord);
    });
    button.addEventListener("pointercancel", () => { dragging = null; render(); });
    button.addEventListener("click", event => { if (event.detail === 0) select(cord); });
    button.addEventListener("keydown", event => {
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      event.preventDefault();
      const from = order.indexOf(cord);
      const to = Math.max(0, Math.min(2, from + (event.key === "ArrowLeft" ? -1 : 1)));
      swap(from, to);
      if (!cordsUntangled(order)) button.focus({ preventScroll: true });
    });
  });

  function finish(solved: boolean): void {
    dialog.close();
    dialog.remove();
    if (solved) onSolved();
    else trigger.focus({ preventScroll: true });
  }
  key.addEventListener("click", () => { if (cordsUntangled(order)) finish(true); });
  dialog.querySelector<HTMLButtonElement>(".puzzle-close")!.addEventListener("click", () => finish(false));
  dialog.addEventListener("cancel", event => { event.preventDefault(); finish(false); });
  document.body.append(dialog);
  render();
  dialog.showModal();
  buttons[0].focus({ preventScroll: true });
}
