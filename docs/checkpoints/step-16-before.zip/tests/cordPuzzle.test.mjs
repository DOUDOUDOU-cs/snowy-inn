import test from 'node:test';
import assert from 'node:assert/strict';
import { CORD_COUNT, initialCordOrder, swapCordEnds, cordsUntangled, cordCrossings, isCordOrder } from '../src/game/cordPuzzle.ts';

test('二十根绳线形成需要多次交换的交错绳阵', () => {
  assert.equal(CORD_COUNT, 20);
  assert.equal(isCordOrder(initialCordOrder), true);
  assert.equal(cordCrossings(initialCordOrder), 98);
  assert.equal(cordsUntangled(initialCordOrder), false);

  let order = initialCordOrder;
  let moves = 0;
  for (let slot = 0; slot < CORD_COUNT; slot++) {
    const other = order.indexOf(slot);
    if (other !== slot) { order = swapCordEnds(order, slot, other); moves++; }
  }
  assert.equal(moves, 18);
  assert.equal(cordCrossings(order), 0);
  assert.equal(cordsUntangled(order), true);
  assert.deepEqual(initialCordOrder.slice(0, 3), [9, 16, 3]);
});

test('绳阵存档只接受二十个不重复的编号', () => {
  assert.equal(isCordOrder([0, 1, 2]), false);
  assert.equal(isCordOrder(Array(20).fill(0)), false);
  assert.equal(isCordOrder([...Array(19).keys(), 20]), false);
  assert.equal(swapCordEnds(initialCordOrder, 0, 20), initialCordOrder);
});
