export const CORD_COUNT = 20;
export type CordOrder = readonly number[];

// 下方木钉由左到右，对应的数字是绳子上端的木钉编号。
// 这一组形成两个长循环，至少要交换 18 次才能全部理顺。
export const initialCordOrder: CordOrder = Object.freeze([
  9, 16, 3, 14, 1, 18, 7, 12, 0, 15,
  5, 19, 10, 2, 17, 6, 13, 4, 11, 8,
]);

export function isCordOrder(value: unknown): value is CordOrder {
  return Array.isArray(value) && value.length === CORD_COUNT
    && value.every(cord => Number.isInteger(cord) && cord >= 0 && cord < CORD_COUNT)
    && new Set(value).size === CORD_COUNT;
}

export function swapCordEnds(order: CordOrder, from: number, to: number): CordOrder {
  if (!isCordOrder(order) || !Number.isInteger(from) || !Number.isInteger(to)
      || from < 0 || from >= CORD_COUNT || to < 0 || to >= CORD_COUNT || from === to) return order;
  const next = [...order];
  [next[from], next[to]] = [next[to], next[from]];
  return next;
}

export function cordsUntangled(order: CordOrder): boolean {
  return isCordOrder(order) && order.every((cord, slot) => cord === slot);
}

export function cordCrossings(order: CordOrder): number {
  let crossings = 0;
  for (let left = 0; left < order.length; left++) {
    for (let right = left + 1; right < order.length; right++) {
      if (order[left] > order[right]) crossings++;
    }
  }
  return crossings;
}
