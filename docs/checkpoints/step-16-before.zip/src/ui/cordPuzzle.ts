import { CORD_COUNT, cordCrossings, cordsUntangled } from "../game/cordPuzzle";
import type { CordOrder } from "../game/cordPuzzle";

const WIDTH = 1040;
const HEIGHT = 315;
const TOP = 42;
const BOTTOM = 250;
const pegX = Array.from({ length: CORD_COUNT }, (_, slot) => 38 + slot * (WIDTH - 76) / (CORD_COUNT - 1));
const colors = ["#a27d6c", "#82918b", "#a79672", "#868b99", "#a08880", "#8e9b7e"];
const label = (cord: number): string => String(cord + 1).padStart(2, "0");

interface MoveResult { order: CordOrder; warning?: string }

export function openCordPuzzle(
  initialOrder: CordOrder,
  onMove: (from: number, to: number) => MoveResult,
  onSolved: () => void,
  onClose: () => void,
): void {
  const dialog = document.createElement("dialog");
  dialog.className = "puzzle-dialog cord-dialog";
  dialog.setAttribute("aria-labelledby", "cord-puzzle-title");
  dialog.setAttribute("aria-describedby", "cord-puzzle-hint");
  dialog.innerHTML = `
    <div class="puzzle-heading">
      <div>
        <p class="puzzle-eyebrow">隔壁客房 · 衣柜内侧</p>
        <h2 id="cord-puzzle-title" tabindex="-1">木板上的绳阵</h2>
      </div>
      <button class="puzzle-close" type="button" aria-label="收起衣柜画面">×</button>
    </div>
    <p class="puzzle-description">二十根旧绳的上端固定在木板上。挪动下方绳端，使每根绳子回到同号木钉，不再与别的绳子交叉。</p>
    <p class="cord-progress" aria-live="polite"></p>
    <div class="cord-viewport" tabindex="0" aria-label="绳阵画板，窄屏可横向滚动">
      <div class="cord-board" role="group" aria-label="二十根交错的绳子">
        <svg class="cord-svg" viewBox="0 0 ${WIDTH} ${HEIGHT}" preserveAspectRatio="none" aria-hidden="true">
          <g class="cord-pegs"></g><g class="cord-lines"></g>
        </svg>
        <button class="cord-key" type="button" aria-label="取下露出的古铜色钥匙" disabled><span class="cord-key-shape" aria-hidden="true"></span></button>
        <div class="cord-handles"></div>
      </div>
    </div>
    <p class="puzzle-hint" id="cord-puzzle-hint" role="status">拖动下方绳端到另一枚木钉，或依次点选两端交换。</p>
    <p class="puzzle-footnote">点选绳端可看清它连接的上方木钉；方向键可与相邻绳端交换。调整会自动保存，按 Esc 可返回房间。</p>`;

  const board = dialog.querySelector<HTMLElement>(".cord-board")!;
  const pegs = dialog.querySelector<SVGGElement>(".cord-pegs")!;
  const lines = dialog.querySelector<SVGGElement>(".cord-lines")!;
  const handles = dialog.querySelector<HTMLElement>(".cord-handles")!;
  const key = dialog.querySelector<HTMLButtonElement>(".cord-key")!;
  const hint = dialog.querySelector<HTMLElement>(".puzzle-hint")!;
  const progress = dialog.querySelector<HTMLElement>(".cord-progress")!;
  let order: CordOrder = [...initialOrder];
  let selected: number | null = null;
  let moves = 0;
  let dragging: { cord: number; from: number; pointer: number; startX: number; startY: number; x: number; y: number; moved: boolean } | null = null;

  pegs.innerHTML = pegX.map((x, cord) => `
    <circle cx="${x}" cy="${TOP}" r="12" fill="#1c2729" stroke="#827968" stroke-width="4"/>
    <text x="${x}" y="17" fill="#c7bb9e" text-anchor="middle" font-size="13">${label(cord)}</text>
    <circle cx="${x}" cy="${BOTTOM}" r="12" fill="#1c2729" stroke="#706c62" stroke-width="4"/>
    <text x="${x}" y="292" fill="#a9a391" text-anchor="middle" font-size="12">${label(cord)}</text>
  `).join("");

  const buttons = Array.from({ length: CORD_COUNT }, (_, cord) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "cord-handle";
    button.style.setProperty("--cord-color", colors[cord % colors.length]);
    button.textContent = label(cord);
    handles.append(button);
    return button;
  });

  function point(event: PointerEvent): { x: number; y: number } {
    const rect = board.getBoundingClientRect();
    return {
      x: Math.max(pegX[0], Math.min(pegX[CORD_COUNT - 1], (event.clientX - rect.left) / rect.width * WIDTH)),
      y: Math.max(TOP + 15, Math.min(HEIGHT - 35, (event.clientY - rect.top) / rect.height * HEIGHT)),
    };
  }

  function render(): void {
    const cords = order.map((cord, slot) => ({ cord, slot }));
    if (selected !== null) cords.sort((a, b) => Number(a.cord === selected) - Number(b.cord === selected));
    lines.innerHTML = cords.map(({ cord, slot }) => {
      const end = dragging?.cord === cord ? { x: dragging.x, y: dragging.y } : { x: pegX[slot], y: BOTTOM };
      const path = `M ${pegX[cord]} ${TOP} C ${pegX[cord]} 110, ${end.x} 178, ${end.x} ${end.y}`;
      const bright = selected === cord || dragging?.cord === cord;
      const opacity = selected !== null && !bright ? ".36" : "1";
      return `<g opacity="${opacity}"><path d="${path}" stroke="#10191b" stroke-width="12" fill="none" stroke-linecap="round"/><path d="${path}" stroke="${colors[cord % colors.length]}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="${path}" stroke="#e7ddc544" stroke-width="2" fill="none" stroke-linecap="round"/></g>`;
    }).join("");
    const solved = cordsUntangled(order);
    buttons.forEach((button, cord) => {
      const slot = order.indexOf(cord);
      const x = dragging?.cord === cord ? dragging.x : pegX[slot];
      const y = dragging?.cord === cord ? dragging.y : BOTTOM;
      button.style.left = `${x / WIDTH * 100}%`;
      button.style.top = `${y / HEIGHT * 100}%`;
      button.classList.toggle("is-selected", selected === cord);
      button.classList.toggle("is-dragging", dragging?.cord === cord);
      button.disabled = solved;
      button.setAttribute("aria-label", `${label(cord)} 号绳端，当前在下方第 ${slot + 1} 个木钉${selected === cord ? "，已选中" : ""}`);
    });
    dialog.classList.toggle("cord-solved", solved);
    key.disabled = !solved;
    progress.textContent = solved ? `全部理顺 · 已调整 ${moves} 次` : `仍有 ${cordCrossings(order)} 处交叉 · 本次打开后调整 ${moves} 次`;
    if (solved) hint.textContent = "绳阵已经解开。木板上的古铜色钥匙现在可以取下。";
  }

  function swap(from: number, to: number): void {
    if (from === to) { render(); return; }
    const result = onMove(from, to);
    order = [...result.order];
    selected = null;
    moves += 1;
    hint.textContent = result.warning || "绳端换了位置。沿着绳线再看看还有哪些地方交叉。";
    render();
    if (cordsUntangled(order)) key.focus({ preventScroll: true });
  }

  function select(cord: number): void {
    if (cordsUntangled(order)) return;
    if (selected === null) {
      selected = cord;
      hint.textContent = `已选中 ${label(cord)} 号绳端。它通向上方 ${label(cord)} 号木钉；再选另一端可交换。`;
      render();
    } else if (selected === cord) {
      selected = null;
      hint.textContent = "放下了绳端。";
      render();
    } else swap(order.indexOf(selected), order.indexOf(cord));
  }

  buttons.forEach((button, cord) => {
    button.addEventListener("pointerdown", event => {
      if (cordsUntangled(order)) return;
      event.preventDefault();
      button.setPointerCapture(event.pointerId);
      const from = order.indexOf(cord);
      dragging = { cord, from, pointer: event.pointerId, startX: event.clientX, startY: event.clientY, x: pegX[from], y: BOTTOM, moved: false };
    });
    button.addEventListener("pointermove", event => {
      if (!dragging || dragging.pointer !== event.pointerId || dragging.cord !== cord) return;
      if (Math.hypot(event.clientX - dragging.startX, event.clientY - dragging.startY) > 7) dragging.moved = true;
      if (dragging.moved) {
        Object.assign(dragging, point(event));
        render();
      }
    });
    button.addEventListener("pointerup", event => {
      if (!dragging || dragging.pointer !== event.pointerId || dragging.cord !== cord) return;
      const { from, moved } = dragging;
      dragging = null;
      if (moved) {
        const x = point(event).x;
        const to = pegX.reduce((best, peg, slot) => Math.abs(peg - x) < Math.abs(pegX[best] - x) ? slot : best, 0);
        swap(from, to);
      } else select(cord);
    });
    button.addEventListener("pointercancel", () => { dragging = null; render(); });
    button.addEventListener("click", event => { if (event.detail === 0) select(cord); });
    button.addEventListener("keydown", event => {
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      event.preventDefault();
      const from = order.indexOf(cord);
      const to = Math.max(0, Math.min(CORD_COUNT - 1, from + (event.key === "ArrowLeft" ? -1 : 1)));
      swap(from, to);
      if (!cordsUntangled(order)) button.focus({ preventScroll: true });
    });
  });

  function finish(solved: boolean): void {
    dialog.close();
    dialog.remove();
    if (solved) onSolved();
    else onClose();
  }
  key.addEventListener("click", () => { if (cordsUntangled(order)) finish(true); });
  dialog.querySelector<HTMLButtonElement>(".puzzle-close")!.addEventListener("click", () => finish(false));
  dialog.addEventListener("cancel", event => { event.preventDefault(); finish(false); });
  document.body.append(dialog);
  render();
  dialog.showModal();
  dialog.querySelector<HTMLElement>("#cord-puzzle-title")!.focus({ preventScroll: true });
}
